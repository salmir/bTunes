package at.ac.tuwien.sepm.musicplayer.service.retriever;

import at.ac.tuwien.sepm.musicplayer.layerCommunication.entity.daoEntity.Album;
import at.ac.tuwien.sepm.musicplayer.service.AlbumService;

/**
 * Created by marjaneh.
 */
public interface AlbumCoverRetriever extends InfoRetriever<Album, AlbumService> {
}
