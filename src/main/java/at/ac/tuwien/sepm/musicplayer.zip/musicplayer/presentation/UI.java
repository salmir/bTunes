package at.ac.tuwien.sepm.musicplayer.presentation;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Created by Lena Lenz.
 */
@Component
@Scope("prototype")
public @interface UI {
}
