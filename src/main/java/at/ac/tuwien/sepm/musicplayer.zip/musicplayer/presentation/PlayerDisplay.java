package at.ac.tuwien.sepm.musicplayer.presentation;


/**
 * Created by Lena Lenz.
 */
@UI
public interface PlayerDisplay {

}
