package at.ac.tuwien.sepm.musicplayer.layerCommunication.entity.type;

import at.ac.tuwien.sepm.musicplayer.layerCommunication.entity.info.InfoOwner;

/**
* Created by Lena Lenz.
*/
public interface OwnerType<A extends InfoOwner> extends EntityType<A>{
}
